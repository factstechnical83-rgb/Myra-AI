package com.example.myra

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.android.material.card.MaterialCardView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    // Speech and TTS
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isListening = false
    private var isTtsReady = false

    // Camera & Flashlight
    private lateinit var cameraManager: CameraManager
    private var cameraId: String? = null
    private var isFlashlightOn = false

    // Gemini AI
    private var geminiModel: GenerativeModel? = null
    private var geminiApiKey: String = BuildConfig.GEMINI_API_KEY

    // UI Elements
    private lateinit var tvStatus: TextView
    private lateinit var tvUserQuery: TextView
    private lateinit var tvAssistantResponse: TextView
    private lateinit var fabMic: FloatingActionButton
    private lateinit var progressBar: ProgressBar
    private lateinit var cardResponse: MaterialCardView
    private lateinit var ivFlashlightIndicator: ImageView
    private lateinit var btnSettings: ImageView

    // Permission Request Launcher
    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false

        if (audioGranted) {
            initializeSpeechRecognizer()
        } else {
            Toast.makeText(this, "Microphone permission is required for Myra.", Toast.LENGTH_SHORT).show()
        }

        if (cameraGranted) {
            setupFlashlight()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        initGemini()
        initTextToSpeech()
        setupFlashlight()
        checkAndRequestPermissions()
        setupListeners()
    }

    private fun bindViews() {
        tvStatus = findViewById(R.id.tvStatus)
        tvUserQuery = findViewById(R.id.tvUserQuery)
        tvAssistantResponse = findViewById(R.id.tvAssistantResponse)
        fabMic = findViewById(R.id.fabMic)
        progressBar = findViewById(R.id.progressBar)
        cardResponse = findViewById(R.id.cardResponse)
        ivFlashlightIndicator = findViewById(R.id.ivFlashlightIndicator)
        btnSettings = findViewById(R.id.btnSettings)
    }

    private fun setupListeners() {
        fabMic.setOnClickListener {
            if (isListening) {
                stopListening()
            } else {
                startListening()
            }
        }

        btnSettings.setOnClickListener {
            showApiKeyDialog()
        }
    }

    // ------------------------------------------------------------------------
    // Permissions Setup
    // ------------------------------------------------------------------------
    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }

        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionsLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            initializeSpeechRecognizer()
        }
    }

    // ------------------------------------------------------------------------
    // Gemini AI Configuration
    // ------------------------------------------------------------------------
    private fun initGemini() {
        // Load custom key from SharedPreferences if configured by user
        val prefs = getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
        val savedKey = prefs.getString("gemini_api_key", null)
        if (!savedKey.isNullOrBlank()) {
            geminiApiKey = savedKey
        }

        if (geminiApiKey.isNotBlank() && geminiApiKey != "YOUR_GEMINI_API_KEY_HERE") {
            geminiModel = GenerativeModel(
                modelName = "gemini-1.5-flash",
                apiKey = geminiApiKey,
                systemInstruction = com.google.ai.client.generativeai.type.content {
                    text(
                        "You are Myra, a friendly, intelligent voice assistant for Android. " +
                        "Provide concise, natural, and helpful answers in 1 to 3 sentences suitable for speech synthesis. " +
                        "Avoid markdown formatting such as asterisks, hashes, or bullet points because your response will be read aloud."
                    )
                }
            )
        }
    }

    private fun showApiKeyDialog() {
        val input = EditText(this).apply {
            hint = "Enter Gemini API Key"
            setText(if (geminiApiKey != "YOUR_GEMINI_API_KEY_HERE") geminiApiKey else "")
        }

        AlertDialog.Builder(this)
            .setTitle("Gemini API Key")
            .setMessage("Provide your Gemini API key to enable AI voice processing:")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val newKey = input.text.toString().trim()
                if (newKey.isNotEmpty()) {
                    geminiApiKey = newKey
                    getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putString("gemini_api_key", newKey)
                        .apply()
                    initGemini()
                    Toast.makeText(this, "API Key saved successfully!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------------
    // Speech Recognition (Speech-to-Text)
    // ------------------------------------------------------------------------
    private fun initializeSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            tvStatus.text = getString(R.string.speech_not_available)
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    tvStatus.text = "Listening..."
                    progressBar.visibility = View.VISIBLE
                }

                override fun onBeginningOfSpeech() {
                    tvStatus.text = "Hearing you..."
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // Could update audio wave visualizer if desired
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    tvStatus.text = "Processing speech..."
                    progressBar.visibility = View.GONE
                }

                override fun onError(error: Int) {
                    isListening = false
                    fabMic.setImageResource(R.drawable.ic_mic)
                    progressBar.visibility = View.GONE
                    val message = getSpeechErrorMessage(error)
                    tvStatus.text = message
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    fabMic.setImageResource(R.drawable.ic_mic)
                    progressBar.visibility = View.GONE

                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val query = matches[0]
                        tvUserQuery.text = query
                        processVoiceQuery(query)
                    } else {
                        tvStatus.text = "Could not catch that. Please tap and speak again."
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partialMatches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!partialMatches.isNullOrEmpty()) {
                        tvUserQuery.text = partialMatches[0]
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            checkAndRequestPermissions()
            return
        }

        // Stop any ongoing TTS before listening
        textToSpeech?.stop()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        speechRecognizer?.startListening(intent)
        isListening = true
        fabMic.setImageResource(R.drawable.ic_mic_active)
        tvStatus.text = "Starting microphone..."
    }

    private fun stopListening() {
        speechRecognizer?.stopListening()
        isListening = false
        fabMic.setImageResource(R.drawable.ic_mic)
        progressBar.visibility = View.GONE
        tvStatus.text = "Tap microphone to speak"
    }

    private fun getSpeechErrorMessage(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
            SpeechRecognizer.ERROR_CLIENT -> "Client-side error."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions."
            SpeechRecognizer.ERROR_NETWORK -> "Network connection error."
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout."
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Tap to try again."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service is busy."
            SpeechRecognizer.ERROR_SERVER -> "Server error occurred."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected."
            else -> "Speech recognition error ($errorCode)."
        }
    }

    // ------------------------------------------------------------------------
    // Text-To-Speech (TTS)
    // ------------------------------------------------------------------------
    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Try device default if US English is unavailable
                textToSpeech?.setLanguage(Locale.getDefault())
            }
            isTtsReady = true

            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    runOnUiThread { tvStatus.text = "Myra is speaking..." }
                }

                override fun onDone(utteranceId: String?) {
                    runOnUiThread { tvStatus.text = "Ready. Tap microphone to speak." }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    runOnUiThread { tvStatus.text = "TTS playback error." }
                }
            })
        } else {
            Toast.makeText(this, "Failed to initialize Text-to-Speech", Toast.LENGTH_SHORT).show()
        }
    }

    private fun speakOut(text: String) {
        if (isTtsReady && text.isNotBlank()) {
            val utteranceId = "MYRA_RESPONSE_${System.currentTimeMillis()}"
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        }
    }

    // ------------------------------------------------------------------------
    // Query Processing & Device Action Router
    // ------------------------------------------------------------------------
    private fun processVoiceQuery(query: String) {
        val lowerQuery = query.lowercase().trim()

        // 1. Device Action: WhatsApp
        if (lowerQuery.contains("open whatsapp") || lowerQuery.contains("launch whatsapp")) {
            handleOpenWhatsApp()
            return
        }

        // 2. Device Action: YouTube
        if (lowerQuery.contains("open youtube") || lowerQuery.contains("launch youtube")) {
            handleOpenYouTube()
            return
        }

        // 3. Device Action: Flashlight
        if (lowerQuery.contains("turn on flashlight") ||
            lowerQuery.contains("turn on the flashlight") ||
            lowerQuery.contains("flashlight on") ||
            lowerQuery.contains("torch on")
        ) {
            setFlashlight(true)
            val response = "Turning on the flashlight."
            displayAndSpeak(response)
            return
        }

        if (lowerQuery.contains("turn off flashlight") ||
            lowerQuery.contains("turn off the flashlight") ||
            lowerQuery.contains("flashlight off") ||
            lowerQuery.contains("torch off")
        ) {
            setFlashlight(false)
            val response = "Turning off the flashlight."
            displayAndSpeak(response)
            return
        }

        if (lowerQuery.contains("toggle flashlight") || lowerQuery.contains("flashlight")) {
            val newState = !isFlashlightOn
            setFlashlight(newState)
            val response = if (newState) "Flashlight turned on." else "Flashlight turned off."
            displayAndSpeak(response)
            return
        }

        // 4. Gemini AI Query Handling
        queryGemini(query)
    }

    private fun displayAndSpeak(response: String) {
        cardResponse.visibility = View.VISIBLE
        tvAssistantResponse.text = response
        speakOut(response)
    }

    // ------------------------------------------------------------------------
    // Gemini API Request
    // ------------------------------------------------------------------------
    private fun queryGemini(userPrompt: String) {
        if (geminiModel == null) {
            val missingKeyMsg = "Gemini API key is not configured. Tap the settings gear at top right to enter your API key."
            displayAndSpeak(missingKeyMsg)
            return
        }

        tvStatus.text = "Thinking..."
        progressBar.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val response = geminiModel?.generateContent(userPrompt)
                val responseText = response?.text?.trim() ?: "I'm sorry, I couldn't generate a response."

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    displayAndSpeak(responseText)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    val errorMsg = "Sorry, I had trouble reaching Gemini: ${e.localizedMessage ?: "Unknown error"}"
                    displayAndSpeak(errorMsg)
                }
            }
        }
    }

    // ------------------------------------------------------------------------
    // Device Actions Implementation
    // ------------------------------------------------------------------------
    private fun handleOpenWhatsApp() {
        val response = "Opening WhatsApp."
        displayAndSpeak(response)

        val launchIntent = packageManager.getLaunchIntentForPackage("com.whatsapp")
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            // WhatsApp is not installed, prompt user or open store
            try {
                val playStoreIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.whatsapp"))
                startActivity(playStoreIntent)
            } catch (e: Exception) {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.whatsapp"))
                startActivity(webIntent)
            }
        }
    }

    private fun handleOpenYouTube() {
        val response = "Opening YouTube."
        displayAndSpeak(response)

        val launchIntent = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            // Fallback to web browser if app is not installed
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            startActivity(webIntent)
        }
    }

    private fun setupFlashlight() {
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            for (id in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cameraId = id
                    break
                }
            }
            if (cameraId == null && cameraManager.cameraIdList.isNotEmpty()) {
                cameraId = cameraManager.cameraIdList[0]
            }
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    private fun setFlashlight(enabled: Boolean) {
        val id = cameraId
        if (id == null) {
            Toast.makeText(this, "No camera flash available on this device", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            cameraManager.setTorchMode(id, enabled)
            isFlashlightOn = enabled
            updateFlashlightUI(enabled)
        } catch (e: CameraAccessException) {
            Toast.makeText(this, "Camera error: ${e.message}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Error toggling flashlight: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateFlashlightUI(isOn: Boolean) {
        if (isOn) {
            ivFlashlightIndicator.visibility = View.VISIBLE
            ivFlashlightIndicator.setColorFilter(ContextCompat.getColor(this, R.color.amber_accent))
        } else {
            ivFlashlightIndicator.visibility = View.GONE
        }
    }

    // ------------------------------------------------------------------------
    // Lifecycle Clean-up
    // ------------------------------------------------------------------------
    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer?.destroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        if (isFlashlightOn) {
            setFlashlight(false)
        }
    }
}
