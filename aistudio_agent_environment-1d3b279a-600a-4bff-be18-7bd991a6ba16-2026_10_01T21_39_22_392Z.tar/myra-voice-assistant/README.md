# Myra - Native Android AI Voice Assistant

Myra is a complete native Android voice assistant built in Kotlin. It integrates Google's Gemini AI for voice conversations and provides hardware and system app triggers.

## Key Features

1. **Speech-to-Text (STT)**: Built with Android's `SpeechRecognizer` and `RecognitionListener` for real-time speech capture and transcription.
2. **Text-to-Speech (TTS)**: Built using Android's native `TextToSpeech` engine with natural prosody and utterance tracking.
3. **Gemini AI Integration**: Uses Google's official Generative AI SDK (`gemini-1.5-flash`) with custom system prompts tailored for conversational speech output.
4. **Device & App Actions**:
   - **Open WhatsApp**: Launches WhatsApp via `packageManager.getLaunchIntentForPackage` (falls back to Play Store/Browser).
   - **Open YouTube**: Launches the YouTube application or browser URL.
   - **Flashlight Control**: Toggles the device flashlight via Android `CameraManager.setTorchMode`.
5. **Dynamic API Key Entry**: Enter and persist your Gemini API key in-app or via `build.gradle.kts`.

## Supported Voice Commands

- *"Open WhatsApp"* / *"Launch WhatsApp"*
- *"Open YouTube"* / *"Launch YouTube"*
- *"Turn on flashlight"* / *"Torch on"*
- *"Turn off flashlight"* / *"Torch off"*
- *"Toggle flashlight"*
- Any general question, e.g.:
  - *"Why is the sky blue?"*
  - *"Tell me a fun fact about Mars."*
  - *"Who wrote Romeo and Juliet?"*

## Configuration

1. Open this project in **Android Studio Hedgehog / Iguana / Jellyfish**.
2. Replace `"YOUR_GEMINI_API_KEY_HERE"` in `app/build.gradle.kts` with your Google AI Gemini API key, OR tap the gear icon in the top right corner of the app screen to paste your key at runtime.
3. Build and run on an Android device or emulator with Google Play Services and Microphone support enabled.
